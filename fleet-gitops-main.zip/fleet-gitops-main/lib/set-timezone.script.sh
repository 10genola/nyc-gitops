# This will be a script that sets the timezone on macOS hosts.
